<p>this project is backend of cash_control mobile application for managing transactions</p>
