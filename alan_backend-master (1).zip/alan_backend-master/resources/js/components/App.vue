<template>
   <div id="app">
     <router-view />
   </div>
 </template>
 
 <script>
 export default {
   name: "App",
 };
 </script>
 
 <style>
 /* Global Styles */
 body {
   font-family: Arial, sans-serif;
   background: #f1f3f8;
   margin: 0;
 }
 </style>
 